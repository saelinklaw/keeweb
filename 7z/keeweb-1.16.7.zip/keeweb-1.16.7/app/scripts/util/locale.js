import Locale from 'locales/base.json';

export { Locale };
