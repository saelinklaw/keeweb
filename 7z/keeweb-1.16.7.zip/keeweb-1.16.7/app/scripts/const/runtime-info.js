const RuntimeInfo = {
    version: '@@VERSION',
    beta: !!'@@BETA',
    buildDate: '@@DATE',
    commit: '@@COMMIT',
    devMode: '@@DEVMODE'
};

export { RuntimeInfo };
