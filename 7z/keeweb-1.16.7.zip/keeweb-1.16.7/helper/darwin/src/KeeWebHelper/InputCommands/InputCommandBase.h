@protocol InputCommandBase

- (void)execute;

@end
