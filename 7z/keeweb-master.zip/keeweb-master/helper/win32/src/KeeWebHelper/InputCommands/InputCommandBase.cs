﻿namespace KeeWebHelper.InputCommands
{
    abstract class InputCommandBase
    {
        public abstract void Execute();
    }
}
